# Scrolla Core

Basis-plug-in voor elke website van [Scrolla!](https://www.scrolla.nl). Vervangt ASE en Admin Menu Editor Pro.

| Module | Wat het doet |
|---|---|
| Algemeen | Bedrijfsgegevens op één plek; Elementor dynamic tags (groep Scrolla) en `[scrolla veld="telefoon" link="1"]` |
| Beheeromgeving | Dashboard "[Bedrijfsnaam] beheerder" met tegels en laatst bewerkt, accent in de huiskleur voor klanten, opgeruimde toolbar, meldingen gebundeld, breder menu, systeemoverzicht, zoekmachinestatus, dupliceren |
| Huisstijl | Leest logo, kleuren, fonts en knopradius uit de Elementor-kit; gebruikt door inloggen, mail, onderhoud en beheer. Eigen loginachtergrond: globale kleur "Login achtergrond" in de kit |
| Inloggen | Inlogpagina in de huisstijl, alleen gebruikersnaam, algemene foutmelding, kolom laatste login |
| Mail | Alle mails (formulieren, wachtwoord, systeem) in een HTML-template in de huisstijl; volledige HTML-mails (WooCommerce) blijven ongemoeid |
| Klantrol | Rol "[Bedrijfsnaam] beheerder" (Redacteur + menu's, met WooCommerce ook winkelbeheer), standaard beperkt via Menu per rol |
| Onnodige onderdelen uit | Gutenberg, reacties, feeds, emoji, oEmbed, jQuery Migrate, Dashicons (voorkant), head-tags |
| Beveiliging | Loginpogingen beperken met log, XML-RPC uit, gebruikers niet op te vragen, applicatiewachtwoorden uit, security-headers |
| Afbeeldingen | Max. 2400px, jpg/png naar webp (82), revisies max. 10 (uitzondering: bestandsnaam eindigt op `-nr`) |
| Menu per rol | Whitelist per rol, ook URL-toegang geblokkeerd; alleen Scrolla kan het instellen |
| Onderhoud | Onderhoudspagina in de huisstijl tijdens updates (drop-in) en handmatige onderhoudsmodus |
| Bouwen | REST-importpunt (alleen Scrolla) voor Elementor-pagina's, templates, kit en afbeeldingen; gebruikt door de ontwikkeltool |
| Berichttypes | Eenvoudige CPT's met velden, als dynamic tags in Elementor |

Instellingen zijn alleen zichtbaar voor Scrolla-beheerders (beheerder met @scrolla.nl-adres of gebruiker "Scrolla").

## Updates

Sites controleren één keer per week op een nieuwe GitHub-release en werken automatisch bij. Direct bijwerken: WP Toolkit > Alles bijwerken, of Dashboard > Updates > Opnieuw controleren.

Release maken: verhoog `Version` en `SCROLLA_CORE_VERSION`, push, en publiceer een GitHub-release met tag `vX.Y.Z`. De broncode-zip van de release wordt automatisch gebruikt.

## Geteste updates

bp.scrolla.dev staat in kanariemodus (`scrolla_kanarie` = `bp.scrolla.dev`; geldt alleen op die host, klonen erven het dus niet) en werkt alles direct bij. Claude test de blueprint en zet de geteste versies in `onderhoud.json`. Elke site haalt dat bestand dagelijks op en werkt de stack automatisch bij tot en met die versies. `terugdraaien` (plug-in of thema van wordpress.org, optioneel per site) zet een versie terug. Status: `GET /wp-json/scrolla/v1/status`.
